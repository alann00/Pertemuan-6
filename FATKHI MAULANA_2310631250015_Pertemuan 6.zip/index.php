<?php
// Array pajak bandara asal
$bandara_asal = [
    "Soekarno Hatta" => 65000,
    "Husein Sastranegara" => 50000,
    "Abdul Rachman Saleh" => 40000,
    "Juanda" => 30000
];

// Array pajak bandara tujuan
$bandara_tujuan = [
    "Ngurah Rai" => 50000,
    "Hasanuddin" => 40000,
    "Inanwatan" => 90000,
    "Sultan Babullah Mudik" => 60000
];

// Variabel untuk hasil
$hasil = [];
$nomor = 1;

// Jika form disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $maskapai = $_POST["maskapai"];
    $asal = $_POST["bandara_asal"];
    $tujuan = $_POST["bandara_tujuan"];
    $harga_tiket = (int)$_POST["harga_tiket"];

    $tanggal = date("Y-m-d"); // Tanggal otomatis hari ini

    $pajak_asal = $bandara_asal[$asal];
    $pajak_tujuan = $bandara_tujuan[$tujuan];
    $total_pajak = $pajak_asal + $pajak_tujuan;
    $total_harga = $harga_tiket + $total_pajak;

    $hasil = [
        "nomor" => $nomor,
        "tanggal" => $tanggal,
        "maskapai" => $maskapai,
        "asal" => $asal,
        "tujuan" => $tujuan,
        "harga_tiket" => $harga_tiket,
        "pajak" => $total_pajak,
        "total_harga" => $total_harga
    ];
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Pendaftaran Rute Penerbangan</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Pendaftaran Rute Penerbangan</h2>
    <form method="post">
        <label>Nama Maskapai:</label><br>
        <input type="text" name="maskapai" required><br><br>

        <label>Bandara Asal:</label><br>
        <select name="bandara_asal" required>
            <option value="">-- Pilih Bandara Asal --</option>
            <?php foreach ($bandara_asal as $nama => $pajak): ?>
                <option value="<?= $nama ?>"><?= $nama ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Bandara Tujuan:</label><br>
        <select name="bandara_tujuan" required>
            <option value="">-- Pilih Bandara Tujuan --</option>
            <?php foreach ($bandara_tujuan as $nama => $pajak): ?>
                <option value="<?= $nama ?>"><?= $nama ?></option>
            <?php endforeach; ?>
        </select><br><br>

        <label>Harga Tiket:</label><br>
        <input type="number" name="harga_tiket" required><br><br>

        <input type="submit" value="Proses">
    </form>

    <?php if (!empty($hasil)): ?>
        <h3>Hasil Pendaftaran</h3>
        <table border="1" cellpadding="5" cellspacing="0">
            <tr><th>Nomor</th><td><?= $hasil["nomor"] ?></td></tr>
            <tr><th>Tanggal</th><td><?= $hasil["tanggal"] ?></td></tr>
            <tr><th>Maskapai</th><td><?= $hasil["maskapai"] ?></td></tr>
            <tr><th>Asal Penerbangan</th><td><?= $hasil["asal"] ?></td></tr>
            <tr><th>Tujuan Penerbangan</th><td><?= $hasil["tujuan"] ?></td></tr>
            <tr><th>Harga Tiket</th><td><?= number_format($hasil["harga_tiket"], 0, ',', '.') ?></td></tr>
            <tr><th>Pajak</th><td><?= number_format($hasil["pajak"], 0, ',', '.') ?></td></tr>
            <tr><th>Total Harga Tiket</th><td><?= number_format($hasil["total_harga"], 0, ',', '.') ?></td></tr>
        </table>
    <?php endif; ?>
</body>
</html>
